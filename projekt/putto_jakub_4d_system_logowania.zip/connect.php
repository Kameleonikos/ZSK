<?php
$servername = "localhost";
$username = "root";
// Create connection
$conn = mysqli_connect($servername, $username, '', "bazaprojekt");
?>
